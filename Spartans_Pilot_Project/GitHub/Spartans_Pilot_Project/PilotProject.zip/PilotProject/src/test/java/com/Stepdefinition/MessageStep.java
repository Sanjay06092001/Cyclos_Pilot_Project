package com.Stepdefinition;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
public class MessageStep {

public static WebDriver driver;

@Before
public void congif() {
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://demo.cyclos.org/ui/login");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS); 
	PageFactory.initElements(driver,Messageclass.class);
}
@Given("I am on the messaging page")
public void i_am_on_the_messaging_page() {
	
	driver.findElement(By.xpath("//input[@placeholder='User']")).sendKeys("demo");
    driver.findElement(By.cssSelector("input[placeholder=\"Password\"]")).sendKeys("1234");
    driver.findElement(By.cssSelector("button[class=\"btn d-flex justify-content-center align-items-center w-100 h-100 btn-primary btn-action-primary\"]")).click();
    
}


@When("I click on the {string} button")
public void i_click_on_the_button(String string) {
	Messageclass.msg.click();
	Messageclass.newMessage.click();
}

@When("select a user from the contact list")
public void select_a_user_from_the_contact_list() {
	Messageclass.sendto.click();
       Select select = new Select(driver.findElement(By.id("id_of_the_dropdown_element")));

       select.selectByVisibleText("User");
}

@When("we have enter the subject {string}")
public void we_have_enter_the_subject(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("select the font {string} for the message")
public void select_the_font_for_the_message(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("Apply italics style to the message")
public void apply_italics_style_to_the_message() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("I enter the following rich text message content:")
public void i_enter_the_following_rich_text_message_content(String docString) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("click the {string} button")
public void click_the_button(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("the message should be sent successfully")
public void the_message_should_be_sent_successfully() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

}
