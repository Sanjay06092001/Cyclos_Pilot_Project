package com.Stepdefinition;

public class Messageclass2 {

}
